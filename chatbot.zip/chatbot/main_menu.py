'''Создаем кнопки главного меню с помощью метода "types.InlineKeyboardMarkup()"
"markup" - объявляет новую переменную InlineKeyboard
"markup.add" – создает отдельную кнопку с параметрами:
"text" - название кнопки
"callback_data" - данные, переданные боту после выбора пользователя
В итоге функция "main_menu()" возвращает переменную "markup" - набор кнопок главного меню'''

from telebot import types

def main_menu():
    markup = types.InlineKeyboardMarkup()
    markup.add(types.InlineKeyboardButton(text='Расписание на неделю',
                                          callback_data='timetable'))
    markup.add(types.InlineKeyboardButton(text='Список учителей',
                                          callback_data='teachers'))
    markup.add(types.InlineKeyboardButton(text='Расписание звонков',
                                          callback_data='bells'))
    markup.add(types.InlineKeyboardButton(text='Образцы заявлений',
                                          callback_data='documents'))
    markup.add(types.InlineKeyboardButton(text='Мероприятия',
                                          callback_data='events'))

    return markup