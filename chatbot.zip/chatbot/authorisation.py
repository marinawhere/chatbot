import sqlite3

'''
На данном шаге мы подключаем ранее созданную базу данных "chatbot_database.db"
и создаем переменную "cursor" для перемещения по ранее упомянутой базе данных.
'''
conn = sqlite3.connect('chatbot_database.db', check_same_thread=False)
cursor = conn.cursor()

def db_authorisation_val(login: str, password: str):
    cursor.execute('INSERT INTO authorise (login, password) VALUES (?, ?, ?, ?)', (login, password))
    conn.commit()

def authorisation_login():
    authorisation_table = cursor.execute('SELECT * FROM authorise').fetchall()
    authdata = []
    for login, password in authorisation_table:
        authdata.append(login)

    return authdata