'''
Для начала импортируем библиотеку Sqlite3 для работы с SQL.
'''
import sqlite3

'''
На данном шаге мы подключаем ранее созданную базу данных "chatbot_database.db"
и создаем переменную "cursor" для перемещения по ранее упомянутой базе данных.
'''
conn = sqlite3.connect('chatbot_database.db', check_same_thread=False)
cursor = conn.cursor()

'''
Теперь создадим функцию, которая будет нужна непосредственно для работы с таблицей.

Создаем переменную "tuesday_table" и передаем в нее все данные таблицы "tuesday" из "chatbot_database.db" с помощью
запроса 'SELECT * FROM tuesday'.

Затем создаем цикл for который автоматически распределяет по переменным соответсвующие элементы кортежа, то есть 
построчно присваивает каждому столбцу значение строки. 

Все эти данные помещаются в переменную "text", которая в итоге представляет собой результат выполнения данной
функции и выводиться в виде таблицы.
'''
def db_tuesday_val(id:int, number:int, time: str, subject: str, classroom:str):
    cursor.execute('INSERT INTO tuesday (id, number, time, subject, classroom) VALUES (?, ?, ?, ?)', (id, number, time, subject, classroom))
    conn.commit()

def timetable_tuesday():
    tuesday_table = cursor.execute('SELECT * FROM tuesday').fetchall()
    text = ''
    for id, number, time, subject, classroom in tuesday_table:
        text += f"{str(number)} {str(time)} {str(subject)} {str(classroom)}\n"
    return text